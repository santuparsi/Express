# Expense Tracker (React)

A web application that I created using MongoDB atlas, Express.js, React.js and Node.js(MERN Stack) which calculates your expenses.
